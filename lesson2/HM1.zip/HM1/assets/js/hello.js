
const name = prompt("What is your name?", "John");

alert(`Hello, ${name}! How are you?`);