
//Вивести суму лише парних чисел у діапазоні від 30 до 80

let sum = 0;

for(let i = 30; i < 80; i += 2){
    sum += i;
}

document.write(sum);