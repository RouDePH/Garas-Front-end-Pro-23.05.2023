

//Визначити, чи є задане шестизначне число дзеркальним? (123321, 147741)

var number = prompt("Введите шестизначное число:",0);


if(!isNaN(number)){

    if(number.length == 6){

            let num0 = number[0];
            let num1 = number[1];
            let num2 = number[2];
            let num3 = number[3];
            let num4 = number[4];
            let num5 = number[5];

            if(num0+num1+num2===num5+num4+num3){
                alert("Число зеркальное "); 
            }else{
                alert("Число не зеркальное");
            }


    }else{

        alert("Число должно быть шестизначным!");

    }

}else{

    alert("Введите число!");

}