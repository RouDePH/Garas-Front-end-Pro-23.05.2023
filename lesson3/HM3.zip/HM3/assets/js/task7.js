

// Дано тризначне число.
// Чи правда, що всі цифри однакові?
// Чи є серед цифр цифри однакові?


var number = prompt("Введите трёхначное число:",0);


if(!isNaN(number)){

    if(number.length == 3){

      if(number[0]==number[1]==number[2]){
        alert("Все цифры числа "+number+" равны");
      }else{
        alert("Цифры введённого числа не равны");
      }

      if(number[0]==number[1]||number[0]==number[2]||number[2]==number[1]){
        alert("В числе есть одинаковые числа");
      }else{
        alert("В числе нет одинаковых чисел ;)");
      }
    

    }else{

        alert("Число должно быть трёхзначным!");

    }

}else{

    alert("Введите число!");

}