
//Знайти суму всіх цілих чисел від 1 до 15

let sum = 0

for(let i = 1; i < 15; i++){
    sum+=i;
}

document.write(sum);