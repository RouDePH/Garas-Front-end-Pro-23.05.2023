
let firstValue = prompt("Enter first value:");

let secondValue = prompt("Enter second value:");

if(firstValue == secondValue){

    alert("Values are equal");

} else {
    alert("Values are not equal");
}