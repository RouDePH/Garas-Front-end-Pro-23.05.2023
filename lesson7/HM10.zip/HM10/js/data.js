
const products = [
    {
      name: 'Футбольный мяч',
      price: 17,
       category: 'Спорт'
    },
    {
      name: 'Теннисная ракетка',
      price: 50,
       category: 'Спорт'
    },
    {
      name: 'Скейтборд',
      price: 75,
      category: 'Спорт'
    },
    { 
      name: 'Смартфон', 
      price: 350, 
      category: 'Электроника' 
    },
    { 
      name: 'Наушники', 
      price: 20, 
      category: 'Электроника' 
    },
    { 
      name: 'Фотокамера', 
      price: 175, 
      category: 'Электроника' 
    },
    { 
      name: 'Книга', 
      price: 5, 
      category: 'Книги' 
    },
    { 
      name: 'Журнал', 
      price: 2, 
      category: 'Книги' 
    },
    { 
      name: 'Букварь', 
      price: 30, 
      category: 'Книги' 
    }
  ];