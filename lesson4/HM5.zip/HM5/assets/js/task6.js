
//Знайти середнє арифметичне всіх цілих чисел від 1 до 500

let sum = 0;

for(let i = 0; i < 500; i += 2){
    sum += i;
}

document.write(sum/500);