// Дано масив об’єктів.
// Вивести масив телефонних номерів користувачів в яких баланс більше ніж 2000 доларів.
// І знайти суму всіх балансів користувачів

let phoneNumbers = [];
let totalSum = 0;

for (let i = 0; i < users.length; i++) {
    let sum = parseFloat(
        users[i].balance
            .replace("$", "")
            .replace(",", "")
    );

    totalSum += sum;

    if (sum > 2000) {
        phoneNumbers.push(users[i].phone);
    }
}

document.write(`<p>Телефоннi номери користувачів в яких баланс більше ніж 2000 доларів:<br>${phoneNumbers}</p>`);

document.write(`<p>Cума всіх балансів користувачів: ${totalSum.toFixed(2)}$</p>`);

